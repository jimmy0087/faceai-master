from setuptools import setup,find_packages
setup(name="faceai",
      version='0.1.1',
      description='Deep Learning library for applications about face.',
      url="https://github.com/jimmy0087/faceai-master",
      author='JimmyYoung',
      license='JimmyYoung',
      packages= find_packages(),
      zip_safe=False
      )