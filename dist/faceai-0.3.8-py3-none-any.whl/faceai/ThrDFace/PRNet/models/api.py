import numpy as np
import os
from skimage.io import imread, imsave
from skimage.transform import estimate_transform, warp
from time import time
import cv2 as cv2
from .predictor import PosPrediction
from skimage.transform import rescale, resize

from ..utils.estimate_pose import estimate_pose
from ..utils.rotate_vertices import frontalize
from ..utils.render_app import get_visibility, get_uv_mask, get_depth_image
from ..utils.write import write_obj_with_colors, write_obj_with_texture
from ..utils.cv_plot import plot_vertices,plot_pose_box

class PRN:
    ''' Joint 3D Face Reconstruction and Dense Alignment with Position Map Regression Network
    Args:
        is_dlib(bool, optional): If true, dlib is used for detecting faces.
        prefix(str, optional): If run at another folder, the absolute path is needed to load the data.
    '''
    def __init__(self, prefix = '.'):

        # resolution of input and output image size.
        self.resolution_inp = 256
        self.resolution_op = 256

        #---- load PRN 
        self.pos_predictor = PosPrediction(self.resolution_inp, self.resolution_op)
        prn_path = os.path.join(prefix, 'net-data/256_256_resfcn256_weight')
        if not os.path.isfile(prn_path + '.data-00000-of-00001'):
            print("please download PRN trained model first.")
            exit()
        self.pos_predictor.restore(prn_path)

        # uv file
        self.uv_kpt_ind = np.loadtxt(prefix + '/uv-data/uv_kpt_ind.txt').astype(np.int32) # 2 x 68 get kpt
        self.face_ind = np.loadtxt(prefix + '/uv-data/face_ind.txt').astype(np.int32) # get valid vertices in the pos map
        self.triangles = np.loadtxt(prefix + '/uv-data/triangles.txt').astype(np.int32) # ntri x 3
        self.canonical_vertices = np.load(prefix + '/uv-data/canonical_vertices.npy')

        self.uv_coords = self.generate_uv_coords()        

    def generate_uv_coords(self):
        resolution = self.resolution_op
        uv_coords = np.meshgrid(range(resolution),range(resolution))
        uv_coords = np.transpose(np.array(uv_coords), [1,2,0])
        uv_coords = np.reshape(uv_coords, [resolution**2, -1])
        uv_coords = uv_coords[self.face_ind, :]
        uv_coords = np.hstack((uv_coords[:,:2], np.zeros([uv_coords.shape[0], 1])))
        return uv_coords

    def net_forward(self, image):
        ''' The core of out method: regress the position map of a given image.
        Args:
            image: (256,256,3) array. value range: 0~1
        Returns:
            pos: the 3D position map. (256, 256, 3) array.
        '''
        return self.pos_predictor.predict(image)

    def processImg(self, image, recs):
        pos = self.get_pos(image,recs)
        kpt_3d = self.get_landmarks(pos)
        kpt = kpt_3d[:,:2]
        return kpt

    def process3DFile(self,image,recs,depth=False, pose = False,name='default'):
        img_show ={}
        img_inf = {}

        [h, w, c] = image.shape
        pos,vertices,save_color,img_vertices_show = self.get_3D(image,recs)
        kpt_3d = self.get_landmarks(pos)
        img_show["vertices"] = img_vertices_show
        img_inf["vertices"] = vertices
        img_inf["landmarks_3d"] = kpt_3d
        img_inf["color"] = save_color
        img_inf["triangles"] = self.triangles

        kpt = self.get_landmarks(pos)[:,:2]

        if depth:
            depth_image_show ,depth_inf= self.get_depth(vertices,h,w)
            img_show["depth"] = depth_image_show
            img_inf["depth"] = depth_inf
        if pose:
            camera_matrix, pose, image_pose_show = self.get_pose(image,vertices,kpt)
            img_show["pose"] = image_pose_show
            img_inf["pose"] = pose

        return img_show,img_inf

    def get_3D(self,image,recs):
        pos = self.get_pos(image, recs)
        vertices = self.get_vertices(pos)
        colors = self.get_colors(image, vertices)
        image_show = plot_vertices(image, vertices)

        return pos,vertices,colors,image_show

    def get_depth(self,vertices,h,w):
        depth_inf = get_depth_image(vertices, self.triangles, h, w, True)
        depth_image = np.uint8((depth_inf/np.max(depth_inf))*255)
        return depth_image,depth_inf

    def get_pose(self,image,vertices,kpt):
        camera_matrix, pose = estimate_pose(vertices,self.canonical_vertices)
        image_pose = plot_pose_box(image, camera_matrix, kpt,color=(0,255,0))
        return camera_matrix, pose,image_pose

    def get_pos(self, input, image_info = None):
        ''' process image with crop operation.
        Args:
            input: (h,w,3) array or str(image path). image value range:1~255. 
            image_info(optional): the bounding box information of faces. if None, will use dlib to detect face. 

        Returns:
            pos: the 3D position map. (256, 256, 3).
        '''
        if isinstance(input, str):
            try:
                image = imread(input)
            except IOError:
                print("error opening file: ", input)
                return None
        else:
            image = input

        if image.ndim < 3:
            image = np.tile(image[:,:,np.newaxis], [1,1,3])

        if image_info is not None:
            if np.max(image_info.shape) > 4: # key points to get bounding box
                kpt = image_info
                if kpt.shape[0] > 3:
                    kpt = kpt.T
                left = np.min(kpt[0, :]); right = np.max(kpt[0, :])
                top = np.min(kpt[1,:]); bottom = np.max(kpt[1,:])
            else:  # bounding box
                bbox = image_info
                left = bbox[0]; right = bbox[2]; top = bbox[1]; bottom = bbox[3]
            old_size = (right - left + bottom - top)/2
            center = np.array([right - (right - left) / 2.0, bottom - (bottom - top) / 2.0+ old_size*0.14])
            size = int(old_size*1.42)
        else:
            print('warning: no detected face')
            return None

        # crop image
        src_pts = np.array([[center[0]-size/2, center[1]-size/2], [center[0] - size/2, center[1]+size/2], [center[0]+size/2, center[1]-size/2]])
        DST_PTS = np.array([[0,0], [0,self.resolution_inp - 1], [self.resolution_inp - 1, 0]])
        tform = estimate_transform('similarity', src_pts, DST_PTS)

        image = image / 255.
        cropped_image = warp(image, tform.inverse, output_shape=(self.resolution_inp, self.resolution_inp))
        # run our net
        #st = time()
        cropped_pos = self.net_forward(cropped_image)
        #print 'net time:', time() - st

        # restore 
        cropped_vertices = np.reshape(cropped_pos, [-1, 3]).T
        z = cropped_vertices[2,:].copy()/tform.params[0,0]
        cropped_vertices[2,:] = 1
        vertices = np.dot(np.linalg.inv(tform.params), cropped_vertices)
        vertices = np.vstack((vertices[:2,:], z))
        pos = np.reshape(vertices.T, [self.resolution_op, self.resolution_op, 3])
        
        return pos
            
    def get_landmarks(self, pos):
        '''
        Args:
            pos: the 3D position map. shape = (256, 256, 3).
        Returns:
            kpt: 68 3D landmarks. shape = (68, 3).
        '''
        kpt = pos[self.uv_kpt_ind[1,:], self.uv_kpt_ind[0,:], :]
        return kpt


    def get_vertices(self, pos):
        '''
        Args:
            pos: the 3D position map. shape = (256, 256, 3).
        Returns:
            vertices: the vertices(point cloud). shape = (num of points, 3). n is about 40K here.
        '''
        all_vertices = np.reshape(pos, [self.resolution_op**2, -1])
        vertices = all_vertices[self.face_ind, :]

        return vertices

    def get_colors_from_texture(self, texture):
        '''
        Args:
            texture: the texture map. shape = (256, 256, 3).
        Returns:
            colors: the corresponding colors of vertices. shape = (num of points, 3). n is 45128 here.
        '''
        all_colors = np.reshape(texture, [self.resolution_op**2, -1])
        colors = all_colors[self.face_ind, :]

        return colors


    def get_colors(self, image, vertices):
        '''
        Args:
            pos: the 3D position map. shape = (256, 256, 3).
        Returns:
            colors: the corresponding colors of vertices. shape = (num of points, 3). n is 45128 here.
        '''
        [h, w, _] = image.shape
        vertices[:,0] = np.minimum(np.maximum(vertices[:,0], 0), w - 1)  # x
        vertices[:,1] = np.minimum(np.maximum(vertices[:,1], 0), h - 1)  # y
        ind = np.round(vertices).astype(np.int32)

        colors = image[ind[:,1], ind[:,0], :] # n x 3
        colors = colors[:, [2, 1, 0]]
        return colors








